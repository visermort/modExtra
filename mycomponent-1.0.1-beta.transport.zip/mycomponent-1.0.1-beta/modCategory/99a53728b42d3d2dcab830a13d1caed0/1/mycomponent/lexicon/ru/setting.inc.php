<?php

$_lang['area_mycomponent_main'] = 'Основные';

$_lang['setting_mycomponent_some_setting'] = 'Какая-то настройка';
$_lang['setting_mycomponent_some_setting_desc'] = 'Это описание для какой-то настройки';