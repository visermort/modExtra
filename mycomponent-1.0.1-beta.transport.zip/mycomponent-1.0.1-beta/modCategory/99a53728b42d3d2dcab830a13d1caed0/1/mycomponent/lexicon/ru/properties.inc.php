<?php

$_lang['mycomponent_prop_limit'] = 'Ограничение вывода Предметов на странице.';
$_lang['mycomponent_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['mycomponent_prop_sortBy'] = 'Поле сортировки.';
$_lang['mycomponent_prop_sortDir'] = 'Направление сортировки.';
$_lang['mycomponent_prop_tpl'] = 'Чанк оформления каждого ряда Предметов.';
$_lang['mycomponent_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
