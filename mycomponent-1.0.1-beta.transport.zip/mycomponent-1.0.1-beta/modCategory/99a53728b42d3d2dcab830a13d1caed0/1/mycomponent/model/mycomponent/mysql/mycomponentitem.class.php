<?php
require_once (dirname(dirname(__FILE__)) . '/mycomponentitem.class.php');
class myComponentItem_mysql extends myComponentItem {}