<?php

/**
 * @package mycomponent
 */
class myComponentItem extends xPDOSimpleObject
{
}